def extract_resume_features(path):
    skills=['playing']
    sb= 'Maths'
    dg= 'btech'
    exp= '4'
    return skills, sb, dg, exp