import streamlit as st
import mysql.connector
import subprocess

mydb = mysql.connector.connect(
     host="localhost",   # Change this to your database server host
     user="root",        # Change this to your database username
     password="",        # Change this to your database password
     database="resume_job_project"  # Change this to your database name
)
mycursor = mydb.cursor()
print("connection made")

def main():
    st.title("Welcome!")

    option = st.sidebar.selectbox("Select an Operation", ("Login", "Register"))
    if option == "Register":
        st.subheader("Create your profile")
        name = st.text_input("Enter name")
        email = st.text_input("Enter Email")
        phone = st.text_input("Mobile Number")
        password = st.text_input("Password", type="password")
        if st.button("Register"):
            sql = "insert into users(username,email,phone_number,password) values(%s,%s,%s,%s)"
            val = (name, email, phone, password)
            mycursor.execute(sql, val)
            mydb.commit()
            st.success("Registration successful.")

    elif option == "Login":
        st.subheader("Read Records")
        username = st.text_input("Enter name")
        password = st.text_input("Password", type="password")

        def authenticate(username, password):
            mycursor.execute("select username, password from users WHERE username=%s AND password=%s", (username, password))
            user = mycursor.fetchone()
            mydb.close()
            return user is not None

        if st.button("Login"):
            if authenticate(username, password):
                st.session_state.logged_in = True
                st.success("Login successful! Redirecting...")
                # Execute the option_page.py script
                subprocess.Popen(["streamlit", "run", "option_page.py"])
            else:
                st.error("Invalid username or password")

if __name__ == "__main__":
    main()
