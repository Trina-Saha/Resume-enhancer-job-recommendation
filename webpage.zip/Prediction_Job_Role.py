def prediction(skills, sb, dg, exp):
    role= "Sales"
    return role