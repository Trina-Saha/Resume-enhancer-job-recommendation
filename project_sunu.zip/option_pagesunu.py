import streamlit as st
import os
from Job_Role import predict_job_role

# Function to display job recommendation page
def job_recommendation_page():
    st.title("Job Recommendation Module")
    st.write("Upload your resume in PDF format only")
    uploaded_file = st.file_uploader("Upload your resume", type=["pdf"])
    
    if uploaded_file is not None:
        if st.button("Submit"):
            # Save the uploaded file
            file_path = os.path.join("uploads", uploaded_file.name)
            with open(file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            
            # Call predict_job_role function with the file path
            predicted_role = predict_job_role(file_path)
            st.write(f"The predicted job role is: {predicted_role}")

# Main function to run the Streamlit app
def main():
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Resume Enhancer", "Job Recommendation"])

    if page == "Resume Enhancer":
        st.title("Resume Enhancer")
        st.write("This page is under construction.")
    elif page == "Job Recommendation":
        job_recommendation_page()

if __name__ == "__main__":
    main()
